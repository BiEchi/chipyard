// See LICENSE for license details.

#ifndef SRC_MAIN_C_CHARACTER_H
#define SRC_MAIN_C_CHARACTER_H

#include "rocc-software/src/xcustom.h"

#define XCUSTOM_CHAR 2

#endif  // SRC_MAIN_C_CHARACTER_H
