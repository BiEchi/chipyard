Rocket Custom Coprocessor (RoCC) Software
========================================

This is a set of C and RISC-V Assembly macros that help with emitting custom RISC-V instructions for talking with Rocket Custom Coprocessors (RoCCs).
